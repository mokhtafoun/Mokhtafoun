import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform => const FirebaseOptions(
    apiKey: 'AIzaSyCQI5MiCVqiQIcO5-kqO2qnTZHXm0YMyr0',
    appId: '1:804310394898:web:fc22e30dcdea87bd66d0cb',
    messagingSenderId: '804310394898',
    projectId: 'mokhtafoun-app',
    authDomain: 'mokhtafoun-app.firebaseapp.com',
    storageBucket: 'mokhtafoun-app.firebasestorage.app',
    measurementId: 'G-RGJE22V7R3',
  );
}
